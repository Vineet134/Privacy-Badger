<p>An extension that analyzes a website’s privacy practices by checking for trackers, cookies, and scripts, and provides a detailed report on how your data might be used.</p><br>

<b>Features:<b><br> 
<ul>
  <li>The extension could provide an overall privacy score for each website</li>
  <li> alert users when sensitive data is being tracked</li>
  <li>suggest privacy-enhancing alternatives (Upcoming)</li>
</ul>
